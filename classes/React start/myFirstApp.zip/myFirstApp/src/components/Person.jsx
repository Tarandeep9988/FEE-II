
const Person = () => {
    return (
        <>
        <h1>Name: Tarandeep</h1>
        <h2>Roll: 2310992228</h2>
        </>
    )
}

export default Person;