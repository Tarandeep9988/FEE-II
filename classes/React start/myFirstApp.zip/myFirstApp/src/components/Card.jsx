const Card = () => {
    const border = {
        border: '2px solid black',
        padding: '30px',
        flex: 1,
    }
    return(
        <div style={border}>This is a card</div>
    )
}

export default Card;